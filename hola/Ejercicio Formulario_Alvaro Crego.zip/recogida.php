

<?php
var_dump($_REQUEST);